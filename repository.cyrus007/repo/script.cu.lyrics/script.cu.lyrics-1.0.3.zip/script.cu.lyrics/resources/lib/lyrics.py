
import song

class Lyrics:
    def __init__( self ):
        self.song = song.Song()
        self.lyrics = ""
        self.source = ""
