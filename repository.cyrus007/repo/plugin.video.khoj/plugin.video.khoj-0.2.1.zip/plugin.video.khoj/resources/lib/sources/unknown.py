import urllib2, re

class Resolver:
    def __init__(self):
        self.name = 'UNKNOWN'

    def videoURL(self, url):
        return '', 'Not implemented yet.'

